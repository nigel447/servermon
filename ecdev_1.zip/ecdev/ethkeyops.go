package main

import (
	// "crypto/rand"
	"crypto/ecdsa"
	"crypto/rand"
	"encoding/hex"
	 ethcrypto "github.com/ethereum/go-ethereum/crypto"
	 "golang.org/x/crypto/ssh"
	 "golang.org/x/crypto/ed25519"
 
)

func ED205519KeyGen() (pvk ed25519.PrivateKey) {
	_, pvk, err := ed25519.GenerateKey(rand.Reader)
	handleError(err)
	return
}

func GeneECDSAKey()  (key *ecdsa.PrivateKey) {
	key, err := ecdsa.GenerateKey(ethcrypto.S256(), rand.Reader )
	handleError(err)
	return
}

func MarshallECKey(key *ecdsa.PrivateKey) (hexKey string ) {
	hexKey = hex.EncodeToString(ethcrypto.FromECDSA(key))
    return
}

func Marshall205519Key(key ed25519.PrivateKey) (hexKey string ) {
 
	hexKey = hex.EncodeToString(key)
    return
}

func UnMarshallECKey(hexKey string )  (key *ecdsa.PrivateKey) {
	key, err := ethcrypto.HexToECDSA(hexKey)
	handleError(err)
	return
}

// use a public key for ssh verify
func UnMarshall205519Key(key ed25519.PrivateKey) (hexKey string ) {
	key, err :=hex.DecodeString(key)
	handleError(err)
    return
}

 
