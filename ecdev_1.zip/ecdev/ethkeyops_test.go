package main

import (
     "fmt"
	 "golang.org/x/crypto/ssh"
	"testing"
)

// see eth cmd/puppeth ssh go for design options
func TestSerDeKeyOpps(t *testing.T) { 
	// key ssh: only P-256, P-384 and P-521 EC keys are supported
	key := ED205519KeyGen()
	hexStr := Marshall205519Key(key)
	keyDeSer := UnMarshallECKey(hexStr)
	keyDeSer.PublicKey 
}

func TestSSHCompaibility(t *testing.T) {
	key := GeneECDSAKey()
	signer, err := ssh.NewSignerFromKey(key)
	handleError(err)
	// if(!(signer.PublicKey().Type() != "")) {
	// 	t.Errorf("key not campatible ssh" )	
	// }
	fmt.Println(signer.PublicKey().Type())
	
}


