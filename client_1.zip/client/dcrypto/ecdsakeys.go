package dcrypto

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"golang.org/x/crypto/ssh"
)

var (
	typeECPrivateKey = "ECDSA PRIVATE KEY"
)

type (
	// 
	ECDHAuth struct {
		AuthPriKey *ecdsa.PrivateKey
	}
)

func GenECDSAKey() (*ecdsa.PrivateKey, ecdsa.PublicKey, error) {
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, ecdsa.PublicKey{}, err
	}
	return priv, priv.PublicKey, nil
}
 
func GenECDHAuthKey() (authKeys ECDHAuth, err error) {
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return ECDHAuth{}, nil 
	}
	return  ECDHAuth{AuthPriKey: priv }  , nil
}

func GenStaticAuthKey() (authKeys ECDHAuth, err error) {
	ecPriKey, err := UnmarshalECPrivate([]byte(staticPriKey))
	return ECDHAuth{AuthPriKey: ecPriKey}, err
}



func MarshalECPrivate(priv *ecdsa.PrivateKey) []byte {
	private_key_bytes, err := x509.MarshalECPrivateKey(priv)
	handleError(err)
	return pem.EncodeToMemory(&pem.Block{Type: typeECPrivateKey, Bytes: private_key_bytes, })
}

func UnmarshalECPrivate(bytes []byte) (*ecdsa.PrivateKey, error) {
	block, _ := pem.Decode(bytes)
	if block == nil {
		return nil, fmt.Errorf("failed to parse PEM block containing the key")
	}

	return x509.ParseECPrivateKey(block.Bytes)
}

// MarshalAuthorizedKey serializes  like  authorized_keys file
func MarshalECPublicKey(priv *ecdsa.PrivateKey) []byte {
	signer, err := ssh.NewSignerFromKey(priv)
	handleError(err)
	return bytes.TrimSuffix(ssh.MarshalAuthorizedKey(signer.PublicKey()), []byte{'\n'})
}

func UnMarshalECPublic(bytes []byte) (ssh.PublicKey, error) {
	pub, _, _, _, err := ssh.ParseAuthorizedKey(bytes)
	return pub, err
}

func handleError(err error) {
	if err != nil {
		fmt.Println("HandleError ", err.Error())
	}
}

 
 