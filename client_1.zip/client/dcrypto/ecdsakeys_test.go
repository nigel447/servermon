package dcrypto

import (
	"fmt"
	"testing"
)

/**
* 	server knows the clients secret
    I get clients public key and check secret
	for this server / client need static pri key and client needs server pub key
*/
func TestMarshalKeyOpps(t *testing.T) {
	// gen client
	authKeysClient, err := GenECDHAuthKey()
	handleError(err)
	authPriKeyBits := MarshalECPrivate(authKeysClient.AuthPriKey)
	fmt.Println("pem pri key  ", string(authPriKeyBits))
	authPubKeyBits := MarshalECPublicKey(authKeysClient.AuthPriKey)
	fmt.Println("like  authorized_keys file pub key  ", string(authPubKeyBits))
}

func TestUnMarshalKeyOpps(t *testing.T) {
	ecPriKey, err := UnmarshalECPrivate([]byte(staticPriKey))
	handleError(err)
	fmt.Println("UnMarshal EC Private key ", ecPriKey.Curve)
	sshPubKey, err := UnMarshalECPublic([]byte(StaticPubKey))
	handleError(err)
	fmt.Println("UnMarshal EC Public key ", sshPubKey.Type())
}