package dcrypto

const staticPriKey = `-----BEGIN ECDSA PRIVATE KEY-----
MHcCAQEEIIe8gs12MmwsyRP//ZiyV/Nbc6mP4xUTZO92bVqGoY5XoAoGCCqGSM49
AwEHoUQDQgAEKxHiyUryzcrOKFje+EOI6IoO7kyi6N1Ocog33P0jyi9l61R+RnHE
6akt0HfgEY4Bifs21NKSHIjh4fEenrKhFw==
-----END ECDSA PRIVATE KEY-----`

const StaticPubKey = `ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBCsR4slK8s3KzihY3vhDiOiKDu5MoujdTnKIN9z9I8ovZetUfkZxxOmpLdB34BGOAYn7NtTSkhyI4eHxHp6yoRc=`