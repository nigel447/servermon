package main

import (
	//"crypto"
	// "crypto/x509"
	"fmt"
	"testing"
	// "encoding/base64"
	// "crypto/ecdsa"
	// "golang.org/x/crypto/ssh"
)

// func TestKeyGen(t *testing.T) {
// 	authKeysSever, err := GenECDHAuthKey()
// 	handleError(err)
// 	authKeysClient, err := GenECDHAuthKey()
// 	handleError(err)

// 	// create the shared secret with server gets client public key

// 	sharedServer, _ := authKeysSever.AuthPubKey.Curve.ScalarMult(
// 		authKeysSever.AuthPubKey.X, authKeysSever.AuthPubKey.Y, authKeysClient.AuthPriKey.D.Bytes())

// 	// i have this, i get client public key
// 	sharedClient, _ := authKeysClient.AuthPubKey.Curve.ScalarMult(
// 		authKeysClient.AuthPubKey.X, authKeysClient.AuthPubKey.Y, authKeysSever.AuthPriKey.D.Bytes())

// 	fmt.Println("sharedServer", sharedServer)
// 	fmt.Println("sharedClient", sharedClient)
// }

// func TestSshPubToECKey(t *testing.T) {
	// sshPubKey, err := UnMarshalECPublic([]byte(staticPubKey))
	// handleError(err)
	// fmt.Println("UnMarshal EC Public key ", sshPubKey.Type())
	// fmt.Printf("sshPubKey: %v\n", sshPubKey)
	// edsaPubKey, _, err := ParseECDSA(sshPubKey.Marshal())
	// handleError(err)
	// fmt.Println("UnMarshal EC Public key ", edsaPubKey.Y)

	// gen client
	// authKeysClient, err := GenECDHAuthKey()
	// handleError(err)
	// fmt.Println("ssh pub key",authKeysClient.AuthPubKey.Type())
	// edsaPubKey, _, err :=  ParseECDSA(authKeysClient.AuthPubKey.Marshal())
	// handleError(err)

	// fmt.Println("ParseECDSA pub key", edsaPubKey.Curve)
	// encodeRest := make([]byte, base64.StdEncoding.DecodedLen(len(rest)))
	// base64.StdEncoding.Encode(encodeRest, rest)

	// fmt.Println("ParseECDSA rest", encodeRest)

// }

/**
* 	sever knows clients secret
    I get clients public key and check secret
	for this server / client need static pri key and client needs server pub key
*/
func TestMarshalKeyOpps(t *testing.T) {
	// gen client
	authKeysClient, err := GenECDHAuthKey()
	handleError(err)
	authPriKeyBits := MarshalECPrivate(authKeysClient.AuthPriKey)
	fmt.Println("pem pri key", string(authPriKeyBits))
	authPubKeyBits := MarshalECPublicKey(authKeysClient.AuthPriKey)
	fmt.Println("like  authorized_keys file pub key", string(authPubKeyBits))
}

func TestUnMarshalKeyOpps(t *testing.T) {
	ecPriKey, err := UnmarshalECPrivate([]byte(staticPriKey))
	handleError(err)
	fmt.Println("UnMarshal EC Private key ", ecPriKey.Curve)
	sshPubKey, err := UnMarshalECPublic([]byte(staticPubKey))
	handleError(err)
	fmt.Println("UnMarshal EC Public key ", sshPubKey.Type())

	authKeys := ECDHAuth{AuthPriKey: ecPriKey, AuthPubKey: sshPubKey}
	fmt.Println("ECDHAuth ", authKeys)

}

const staticPriKey = `-----BEGIN ECDSA PRIVATE KEY-----
MHcCAQEEIJz4GESqoPHuAMpttcRcRol4vqN573BLZI94WavWiF+coAoGCCqGSM49
AwEHoUQDQgAERDgIOlrOmprIVrpq9ke+WUZb6ivwsf94p/BUigJ1DyOmqJIjvEy0
fzoHysIuwi6X+7HGwY1/gGc+uXoKs/ts5A==
-----END ECDSA PRIVATE KEY-----`

const staticPubKey = `ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBCsR4slK8s3KzihY3vhDiOiKDu5MoujdTnKIN9z9I8ovZetUfkZxxOmpLdB34BGOAYn7NtTSkhyI4eHxHp6yoRc=`

