package main

import (
	"crypto"
	"crypto/rand"

	"encoding/hex"
	// "fmt"
	"golang.org/x/crypto/ed25519"
	"golang.org/x/crypto/ssh"
	// "golang.org/x/crypto/ssh"
)

var ()

func ED205519KeyGen() (pvk ed25519.PrivateKey) {

	_, pvk, err := ed25519.GenerateKey(rand.Reader)
	handleError(err)
	return
}

func Marshal205519PubK(pk crypto.PublicKey) string {
	return hex.EncodeToString(pk.(ed25519.PublicKey))
}

func UnMarshallPubK(serKey string) (pk ssh.PublicKey) {
	bits, err := hex.DecodeString(serKey)
	handleError(err)
 
	pk, err = ssh.ParsePublicKey(bits)
	handleError(err)
	return
}
