package main

import (
	"crypto"
	//"crypto/ed25519"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"testing"

	"golang.org/x/crypto/ssh"
)

func TestSerDeE25519BasicFlow(t *testing.T) {
	prik := ED205519KeyGen()
	signer, err := ssh.NewSignerFromKey(prik)
	handleError(err)
	fmt.Println(signer.PublicKey().Type())
	fmt.Println(ssh.FingerprintSHA256(signer.PublicKey()))
	serPk := Marshal205519PubK(prik.Public())
	fmt.Println(serPk)
    derPk :=  UnMarshallPubK(serPk)
	fmt.Println(derPk.Type() )
}

func TestSerDeE25519Serde(t *testing.T) {
	prik := ED205519KeyGen()
 

}

 


