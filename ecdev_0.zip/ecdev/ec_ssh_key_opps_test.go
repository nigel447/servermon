package main

import (
	"encoding/base64"
	"fmt"
	"testing"
	// "golang.org/x/crypto/ssh"

)

func TestB64Encoding(t *testing.T) { 
	authKeysSever, err := GenECDHAuthKey()
	handleError(err)
	bits := MarshalECPublicKeyToSSH(authKeysSever.AuthPriKey)
	str := base64.StdEncoding.EncodeToString( bits)
	fmt.Println("encodeRest ", str)
}

func TestDecodeB64SSHPubKey(t *testing.T) {
	bits, err := base64.StdEncoding.DecodeString( sshPubKeyB64)
	handleError(err)
	keySlice := make([]byte, len([]byte(`ecdsa-sha2-nistp256 `)))
	keySlice = append(keySlice, bits...)
	fmt.Println("keySlice ", string(keySlice) )
	pubKey,_,_ := ParseECDSA(keySlice)
	handleError(err)
	fmt.Println("sshPubKey ", pubKey.Curve )


}

const sshPubKeyB64 = `AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBCsR4slK8s3KzihY3vhDiOiKDu5MoujdTnKIN9z9I8ovZetUfkZxxOmpLdB34BGOAYn7NtTSkhyI4eHxHp6yoRc=`